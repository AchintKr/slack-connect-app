import React from "react";

function ConnectButton() {
  const handleConnect = async () => {
    const res = await fetch("http://localhost:5000/api/auth/connect");
    const data = await res.json();
    alert(data.status);
  };

  return <button onClick={handleConnect}>Connect to Slack (Mock)</button>;
}

export default ConnectButton;
