import React, { useEffect, useState } from "react";

function ScheduledList() {
  const [messages, setMessages] = useState<any[]>([]);

  const fetchMessages = async () => {
    const res = await fetch("http://localhost:5000/api/messages/scheduled");
    const data = await res.json();
    setMessages(data);
  };

  const cancelMessage = async (index: number) => {
    await fetch(`http://localhost:5000/api/messages/scheduled/${index}`, {
      method: "DELETE",
    });
    fetchMessages();
  };

  useEffect(() => {
    fetchMessages();
  }, []);

  return (
    <div>
      <h2>Scheduled Messages</h2>
      <ul>
        {messages.map((msg, idx) => (
          <li key={idx}>
            {msg.channel} - {msg.text} at {msg.time}
            <button onClick={() => cancelMessage(idx)}>Cancel</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default ScheduledList;
