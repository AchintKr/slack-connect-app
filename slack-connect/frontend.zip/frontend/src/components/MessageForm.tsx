import React, { useState } from "react";

interface Props {
  onMessageSent: () => void;
}

function MessageForm({ onMessageSent }: Props) {
  const [channel, setChannel] = useState("");
  const [text, setText] = useState("");
  const [time, setTime] = useState("");

  const sendMessage = async () => {
    await fetch("http://localhost:5000/api/messages/send", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ channel, text }),
    });
    onMessageSent();
  };

  const scheduleMessage = async () => {
    await fetch("http://localhost:5000/api/messages/schedule", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ channel, text, time }),
    });
    onMessageSent();
  };

  return (
    <div>
      <input placeholder="Channel" value={channel} onChange={e => setChannel(e.target.value)} />
      <input placeholder="Message" value={text} onChange={e => setText(e.target.value)} />
      <input type="datetime-local" value={time} onChange={e => setTime(e.target.value)} />
      <button onClick={sendMessage}>Send Now</button>
      <button onClick={scheduleMessage}>Schedule</button>
    </div>
  );
}

export default MessageForm;
