import React from "react";
import ConnectButton from "./components/ConnectButton";
import MessageForm from "./components/MessageForm";
import ScheduledList from "./components/ScheduledList";

function App() {
  const refreshList = () => {
    window.location.reload();
  };

  return (
    <div>
      <h1>Slack Connect (Mock)</h1>
      <ConnectButton />
      <MessageForm onMessageSent={refreshList} />
      <ScheduledList />
    </div>
  );
}

export default App;
